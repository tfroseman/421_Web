function checkanswers(clientanswers){

}

var correctanswers = {
    "question1":{"answer":1},
    "question2":{"answer":1},
    "question3":{"answer":3},
    "question4":{"answer":2},
    "question5":{"answer":2},
    "question6":{"answer":2},
    "question7":{"answer":3},
    "question8":{"answer":1},
    "question9":{"answer":1},
    "question10":{"answer":3}
};